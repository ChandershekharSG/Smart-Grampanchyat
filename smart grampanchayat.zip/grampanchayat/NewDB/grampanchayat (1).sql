-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 15, 2021 at 09:14 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grampanchayat`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `updationDate`) VALUES
(1, 'admin', 'Test@12345', '28-12-2016 11:42:05 AM');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `doctorSpecialization` varchar(255) DEFAULT NULL,
  `doctorId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `consultancyFees` int(11) DEFAULT NULL,
  `appointmentDate` varchar(255) DEFAULT NULL,
  `appointmentTime` varchar(255) DEFAULT NULL,
  `postingDate` timestamp NULL DEFAULT current_timestamp(),
  `userStatus` int(11) DEFAULT NULL,
  `doctorStatus` int(11) DEFAULT NULL,
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `doctorSpecialization`, `doctorId`, `userId`, `consultancyFees`, `appointmentDate`, `appointmentTime`, `postingDate`, `userStatus`, `doctorStatus`, `updationDate`) VALUES
(3, 'Demo test', 7, 6, 600, '2019-06-29', '9:15 AM', '2019-06-23 18:31:28', 1, 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `birthcertificate`
--

CREATE TABLE `birthcertificate` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `fathername` varchar(255) NOT NULL,
  `mothername` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `birthtime` time NOT NULL,
  `birthplace` varchar(255) NOT NULL,
  `hospitalname` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `gender` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `birthcertificate`
--

INSERT INTO `birthcertificate` (`id`, `user_id`, `name`, `fathername`, `mothername`, `dob`, `birthtime`, `birthplace`, `hospitalname`, `address`, `gender`, `created_at`, `updated_at`) VALUES
(1, 8, 'chetan', 'Murthy', 'Lakshmi', '1989-05-08', '09:30:00', 'Mangalore', 'MP', 'Test Address', 'Male', '2021-08-14 15:48:58', '2021-08-14 15:48:58');

-- --------------------------------------------------------

--
-- Table structure for table `deathcertificate`
--

CREATE TABLE `deathcertificate` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `fathername` varchar(255) NOT NULL,
  `mothername` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `address` text NOT NULL,
  `deathcause` text NOT NULL,
  `deathdate` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `deathcertificate`
--

INSERT INTO `deathcertificate` (`id`, `name`, `fathername`, `mothername`, `dob`, `address`, `deathcause`, `deathdate`, `user_id`, `created_at`, `updated_at`) VALUES
(2, 'jhkjh', 'jkhkj', 'jhkjh', '2021-08-14', 'jhkjh', 'jhk', '2021-08-14', 8, '2021-08-14 17:24:23', '2021-08-14 17:24:23'),
(3, 'Chetan S', 'Murthy', 'Lakshmi', '2021-08-14', 'Test', 'Heart Attack', '2021-08-14', 8, '2021-08-14 17:25:22', '2021-08-14 17:25:22');

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `specilization` varchar(255) DEFAULT NULL,
  `doctorName` varchar(255) DEFAULT NULL,
  `address` longtext DEFAULT NULL,
  `docFees` varchar(255) DEFAULT NULL,
  `contactno` bigint(11) DEFAULT NULL,
  `docEmail` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `specilization`, `doctorName`, `address`, `docFees`, `contactno`, `docEmail`, `password`, `creationDate`, `updationDate`) VALUES
(7, 'Demo test', 'abc ', 'New Delhi India', '200', 852888888, 'test@demo.com', 'f925916e2754e5e03f75dd58a5733251', '2017-01-07 08:08:58', '2019-06-23 18:17:25'),
(8, 'Scheme1a', 'Test PDO', 'Xyz Abc New Delhi', '600', 1234567890, 'test@test.com', '68a24878cc568766b735c62be5f306ed', '2019-06-23 17:57:43', '2021-08-12 18:54:28'),
(11, 'Test', 'Jonah Juarez', 'Surigao Philippines', '2000', 123456789, 'jjuarez@gmail.com', '25f9e794323b453885f5181f1b624d0b', '2020-07-05 02:06:00', '2021-08-12 18:54:33'),
(12, 'Scheme1a', 'Pdo1a', 'pdo address', '800', 9000000090, 'pdo@gmail.com', '68a24878cc568766b735c62be5f306ed', '2021-08-12 17:04:26', '2021-08-12 17:05:16');

-- --------------------------------------------------------

--
-- Table structure for table `doctorslog`
--

CREATE TABLE `doctorslog` (
  `id` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `userip` binary(16) DEFAULT NULL,
  `loginTime` timestamp NULL DEFAULT current_timestamp(),
  `logout` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorslog`
--

INSERT INTO `doctorslog` (`id`, `uid`, `username`, `userip`, `loginTime`, `logout`, `status`) VALUES
(20, 7, 'test@demo.com', 0x3a3a3100000000000000000000000000, '2020-07-05 01:50:01', '12-08-2021 11:19:04 AM', 1),
(21, NULL, 'juarez@gmail.com', 0x3a3a3100000000000000000000000000, '2020-07-05 02:02:51', NULL, 0),
(22, NULL, 'juarez@gmail.com', 0x3a3a3100000000000000000000000000, '2020-07-05 02:03:03', NULL, 0),
(23, NULL, 'jjuarez@gmail.com', 0x3a3a3100000000000000000000000000, '2020-07-05 02:04:02', NULL, 0),
(24, NULL, 'jjuarez@gmail.com', 0x3a3a3100000000000000000000000000, '2020-07-05 02:04:38', NULL, 0),
(25, 11, 'jjuarez@gmail.com', 0x3a3a3100000000000000000000000000, '2020-07-05 02:06:19', NULL, 1),
(26, 11, 'jjuarez@gmail.com', 0x3a3a3100000000000000000000000000, '2020-07-05 02:06:38', NULL, 1),
(27, 11, 'jjuarez@gmail.com', 0x3a3a3100000000000000000000000000, '2020-07-05 02:08:18', NULL, 1),
(28, 11, 'jjuarez@gmail.com', 0x3a3a3100000000000000000000000000, '2020-07-05 02:15:25', NULL, 1),
(29, 7, 'test@demo.com', 0x3a3a3100000000000000000000000000, '2021-08-12 05:53:06', '12-08-2021 11:23:50 AM', 1),
(30, 8, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-12 09:29:53', '12-08-2021 03:00:12 PM', 1),
(31, 8, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-12 11:00:08', '12-08-2021 06:50:11 PM', 1),
(32, 8, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-12 13:20:23', '12-08-2021 06:52:15 PM', 1),
(33, 8, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-12 13:24:41', '12-08-2021 06:54:51 PM', 1),
(34, 8, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-12 13:24:59', '12-08-2021 06:55:27 PM', 1),
(35, 8, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-12 13:25:32', '12-08-2021 06:55:38 PM', 1),
(36, 8, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-12 13:27:20', '12-08-2021 06:57:25 PM', 1),
(37, 8, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-12 13:27:52', '12-08-2021 06:57:57 PM', 1),
(38, 8, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-12 13:28:09', '12-08-2021 06:58:17 PM', 1),
(39, 8, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-12 13:28:54', '12-08-2021 06:58:59 PM', 1),
(40, 8, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-12 13:41:37', NULL, 1),
(41, NULL, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-12 16:44:39', NULL, 0),
(42, 8, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-12 16:49:49', '12-08-2021 10:20:55 PM', 1),
(43, NULL, 'pdo1a', 0x3a3a3100000000000000000000000000, '2021-08-12 17:33:35', NULL, 0),
(44, 8, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-12 17:35:07', NULL, 1),
(45, NULL, 'test pdo', 0x3a3a3100000000000000000000000000, '2021-08-12 17:49:17', NULL, 0),
(46, 8, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-12 17:49:42', NULL, 1),
(47, 8, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-12 18:27:20', NULL, 1),
(48, 8, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-12 18:29:37', NULL, 1),
(49, 8, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-12 18:30:25', NULL, 1),
(50, 8, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-12 18:30:34', NULL, 1),
(51, 8, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-12 18:30:45', '13-08-2021 12:41:37 AM', 1),
(52, 12, 'pdo@gmail.com', 0x3a3a3100000000000000000000000000, '2021-08-12 19:12:03', '13-08-2021 12:42:22 AM', 1),
(53, 8, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-13 12:46:33', NULL, 1),
(54, 8, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-13 14:50:19', '13-08-2021 08:21:36 PM', 1),
(55, 8, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-14 17:56:44', '14-08-2021 11:45:50 PM', 1),
(56, 8, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-15 07:03:19', '15-08-2021 12:41:17 PM', 1);

-- --------------------------------------------------------

--
-- Table structure for table `doctorspecilization`
--

CREATE TABLE `doctorspecilization` (
  `id` int(11) NOT NULL,
  `specilization` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorspecilization`
--

INSERT INTO `doctorspecilization` (`id`, `specilization`, `creationDate`, `updationDate`) VALUES
(9, 'Demo test', '2016-12-28 07:37:39', '0000-00-00 00:00:00'),
(11, 'Test', '2019-06-23 17:51:06', '2019-06-23 17:55:06'),
(14, 'Scheme1a', '2021-08-12 17:00:07', '2021-08-12 17:02:17');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `posted_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `description`, `posted_date`, `created_at`, `updated_at`) VALUES
(1, 'News Title', 'News decription', '2021-08-02', '2021-08-12 18:39:29', '2021-08-12 18:39:29');

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactus`
--

CREATE TABLE `tblcontactus` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contactno` bigint(12) DEFAULT NULL,
  `message` mediumtext DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp(),
  `AdminRemark` mediumtext DEFAULT NULL,
  `LastupdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `IsRead` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcontactus`
--

INSERT INTO `tblcontactus` (`id`, `fullname`, `email`, `contactno`, `message`, `PostingDate`, `AdminRemark`, `LastupdationDate`, `IsRead`) VALUES
(1, 'test user', 'test@gmail.com', 2523523522523523, ' This is sample text for the test.', '2019-06-29 19:03:08', 'Test Admin Remark', '2019-06-30 12:55:23', 1),
(2, 'Lyndon Bermoy', 'serbermz2020@gmail.com', 1111111111111111, ' This is sample text for testing.  This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing.', '2019-06-30 13:06:50', 'Answered', '2020-07-05 02:13:25', 1),
(3, 'fdsfsdf', 'fsdfsd@ghashhgs.com', 3264826346, 'sample text   sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  ', '2019-11-10 18:53:48', 'vfdsfgfd', '2019-11-10 18:54:04', 1),
(4, 'demo', 'demo@gmail.com', 123456789, ' hi, this is a demo', '2020-07-05 01:57:20', 'answered', '2020-07-05 01:57:46', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblmedicalhistory`
--

CREATE TABLE `tblmedicalhistory` (
  `ID` int(10) NOT NULL,
  `PatientID` int(10) DEFAULT NULL,
  `BloodPressure` varchar(200) DEFAULT NULL,
  `BloodSugar` varchar(200) NOT NULL,
  `Weight` varchar(100) DEFAULT NULL,
  `Temperature` varchar(200) DEFAULT NULL,
  `MedicalPres` mediumtext DEFAULT NULL,
  `CreationDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblpatient`
--

CREATE TABLE `tblpatient` (
  `ID` int(10) NOT NULL,
  `Docid` int(10) DEFAULT NULL,
  `PatientName` varchar(200) DEFAULT NULL,
  `PatientContno` bigint(10) DEFAULT NULL,
  `PatientEmail` varchar(200) DEFAULT NULL,
  `PatientGender` varchar(50) DEFAULT NULL,
  `PatientAdd` mediumtext DEFAULT NULL,
  `PatientAge` int(10) DEFAULT NULL,
  `PatientMedhis` mediumtext DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpatient`
--

INSERT INTO `tblpatient` (`ID`, `Docid`, `PatientName`, `PatientContno`, `PatientEmail`, `PatientGender`, `PatientAdd`, `PatientAge`, `PatientMedhis`, `CreationDate`, `UpdationDate`) VALUES
(7, 8, 'Visitor1', 9087654321, 'visit@gmail.com', 'Female', 'No 56, Jaynagar, Bangalore', 28, 'Test Messages', '2021-08-12 11:21:50', '2021-08-12 13:52:36'),
(8, 8, 'Sanjay', 9878787898, 'sanjay@gmail.com', 'male', 'No 678, rtngr, banglore ', 35, 'Message Visit officer regarding sign', '2021-08-12 11:26:55', NULL),
(9, 8, 'pooja', 9090989898, 'pooja@gmail.com', 'Female', 'no 677, vijaynagar, Bangalore', 38, 'Nill', '2021-08-12 13:53:31', '2021-08-12 13:53:46');

-- --------------------------------------------------------

--
-- Table structure for table `tender`
--

CREATE TABLE `tender` (
  `id` int(11) NOT NULL,
  `tender_title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `tender_date` date NOT NULL,
  `amount` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tender`
--

INSERT INTO `tender` (`id`, `tender_title`, `description`, `tender_date`, `amount`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Tender one', 'Tender description', '2021-08-02', 20000, 1, '2021-08-12 19:06:46', '2021-08-12 19:06:46'),
(3, 'Tender 2', 'Tender Information', '2021-08-08', 1000, 0, '2021-08-15 07:03:51', '2021-08-15 07:03:51');

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `userip` binary(16) DEFAULT NULL,
  `loginTime` timestamp NULL DEFAULT current_timestamp(),
  `logout` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `uid`, `username`, `userip`, `loginTime`, `logout`, `status`) VALUES
(24, 2, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2020-07-05 01:50:24', NULL, 1),
(25, NULL, 'serbermz2020@gmail.com', 0x3a3a3100000000000000000000000000, '2020-07-05 02:09:18', NULL, 0),
(26, NULL, 'serbermz2020@gmail.com', 0x3a3a3100000000000000000000000000, '2020-07-05 02:11:05', NULL, 0),
(27, NULL, 'test@demo.com', 0x3a3a3100000000000000000000000000, '2020-07-05 02:11:24', NULL, 0),
(28, NULL, 'serbermz2020@gmail.com', 0x3a3a3100000000000000000000000000, '2020-07-05 02:11:46', NULL, 0),
(29, 2, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2020-07-05 02:12:00', NULL, 1),
(30, 2, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2021-08-12 05:49:20', '12-08-2021 11:21:03 AM', 1),
(31, 2, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2021-08-12 05:54:10', '12-08-2021 11:24:15 AM', 1),
(32, NULL, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2021-08-12 08:53:14', NULL, 0),
(33, NULL, 'shruthi', 0x3a3a3100000000000000000000000000, '2021-08-12 08:59:55', NULL, 0),
(34, NULL, 'admin', 0x3a3a3100000000000000000000000000, '2021-08-12 09:00:54', NULL, 0),
(35, NULL, 'test@test.com', 0x3a3a3100000000000000000000000000, '2021-08-12 15:56:08', NULL, 0),
(36, 8, 'shruthi@gmail.com', 0x3a3a3100000000000000000000000000, '2021-08-12 15:56:32', '12-08-2021 09:30:52 PM', 1),
(37, 8, 'shruthi@gmail.com', 0x3a3a3100000000000000000000000000, '2021-08-12 19:13:12', '13-08-2021 12:43:21 AM', 1),
(38, 8, 'shruthi@gmail.com', 0x3a3a3100000000000000000000000000, '2021-08-14 14:24:46', '14-08-2021 11:25:17 PM', 1),
(39, NULL, 'shruthi', 0x3a3a3100000000000000000000000000, '2021-08-15 06:32:26', NULL, 0),
(40, NULL, 'admin', 0x3a3a3100000000000000000000000000, '2021-08-15 06:32:32', NULL, 0),
(41, NULL, 'shruthi', 0x3a3a3100000000000000000000000000, '2021-08-15 06:32:41', NULL, 0),
(42, 8, 'shruthi@gmail.com', 0x3a3a3100000000000000000000000000, '2021-08-15 06:33:03', '15-08-2021 12:22:57 PM', 1),
(43, NULL, 'Shruthi', 0x3a3a3100000000000000000000000000, '2021-08-15 06:57:28', NULL, 0),
(44, NULL, 'shruthi', 0x3a3a3100000000000000000000000000, '2021-08-15 06:57:34', NULL, 0),
(45, NULL, 'shruthi', 0x3a3a3100000000000000000000000000, '2021-08-15 06:57:44', NULL, 0),
(46, 8, 'shruthi@gmail.com', 0x3a3a3100000000000000000000000000, '2021-08-15 06:58:01', '15-08-2021 12:32:48 PM', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `address` longtext DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `regDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullName`, `address`, `city`, `gender`, `email`, `password`, `regDate`, `updationDate`) VALUES
(2, 'Demo User', 'Manila, Philippines', 'Delhi', 'female', 'test@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2016-12-30 05:34:39', '2020-07-05 01:55:24'),
(8, 'Shruthi', 'Kuvempunagar', 'Mysore', 'female', 'shruthi@gmail.com', '68a24878cc568766b735c62be5f306ed', '2021-08-12 08:58:40', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `birthcertificate`
--
ALTER TABLE `birthcertificate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deathcertificate`
--
ALTER TABLE `deathcertificate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctorslog`
--
ALTER TABLE `doctorslog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctorspecilization`
--
ALTER TABLE `doctorspecilization`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcontactus`
--
ALTER TABLE `tblcontactus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblmedicalhistory`
--
ALTER TABLE `tblmedicalhistory`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblpatient`
--
ALTER TABLE `tblpatient`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tender`
--
ALTER TABLE `tender`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `birthcertificate`
--
ALTER TABLE `birthcertificate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `deathcertificate`
--
ALTER TABLE `deathcertificate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `doctorslog`
--
ALTER TABLE `doctorslog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `doctorspecilization`
--
ALTER TABLE `doctorspecilization`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblcontactus`
--
ALTER TABLE `tblcontactus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblmedicalhistory`
--
ALTER TABLE `tblmedicalhistory`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblpatient`
--
ALTER TABLE `tblpatient`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tender`
--
ALTER TABLE `tender`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
