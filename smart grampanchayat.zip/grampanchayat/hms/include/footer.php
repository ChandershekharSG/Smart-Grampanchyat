<footer>
				<div class="footer-inner">
					<div class="pull-left">
				
					</div>
					<div class="pull-right">
						<span class="go-top"><i class="ti-angle-up"></i></span>
					</div>
				</div>
			</footer>